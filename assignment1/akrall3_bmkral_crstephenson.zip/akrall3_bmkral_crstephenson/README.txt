Brandon Kral 	bmkral
Cade Stephenson crstephenson
Alexander Krall	akrall3

Xilinx synthesis tool version: Vivado v2020.2 (64-bit)

target FPGA and speed grade: xc7a100tcsg324-1

Method of calculating critical path:
Using the vivado measured critical paths for each component, we summed the latencies at each step in the logic flow. After the timelines for all paths had been defined, we found the critical path as the path with the longest timeline.